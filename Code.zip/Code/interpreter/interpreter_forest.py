import operator


class interpreter_forest():

    def __init__(self, tree=[]):
        self.trees=tree


    def predict(self, X):
        list_predicted = []
        matrix_of_predictions = []
        for model in self.trees:
            matrix_of_predictions.append(model.predict(X))
        for i in range(len(matrix_of_predictions[0])):
            attr = {}
            for j in range(self.NT):
                if matrix_of_predictions[j][i] not in attr:
                    attr[matrix_of_predictions[j][i]] = 1
                else:
                    attr[matrix_of_predictions[j][i]] = attr[matrix_of_predictions[j][i]] + 1
            list_predicted.append(max(attr.items(), key=operator.itemgetter(1))[0])
        return list_predicted

    def compute_classification_accuracy(self, X, Y):
        Y.reset_index(inplace=True, drop=True)
        list_predicted = []
        matrix_of_predictions = []
        for model in self.trees:
            matrix_of_predictions.append(model.predict(X))
        for i in range(len(matrix_of_predictions[0])):
            attr = {}
            for j in range(len(self.trees)):
                if matrix_of_predictions[j][i] not in attr:
                    attr[matrix_of_predictions[j][i]] = 1
                else:
                    attr[matrix_of_predictions[j][i]] = attr[matrix_of_predictions[j][i]] + 1
            list_predicted.append(max(attr.items(), key=operator.itemgetter(1))[0])
        good_classified=0
        for i in range(len(Y)):
            if Y[i]==list_predicted[i]:
                good_classified=good_classified+1
        return good_classified/len(Y)
