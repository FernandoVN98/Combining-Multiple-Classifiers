import math
import operator

from tree_classifiers.cart_random import cart_random


class random_forest():
    def __init__(self, NT=1, F=1):
        self.NT = NT
        self.F = F
        self.trees = []
        self.features = {}

    def predict(self, X):
        list_predicted = []
        matrix_of_predictions = []
        for model in self.trees:
            matrix_of_predictions.append(model.predict(X))
        for i in range(len(matrix_of_predictions[0])):
            attr = {}
            for j in range(self.NT):
                if matrix_of_predictions[j][i] not in attr:
                    attr[matrix_of_predictions[j][i]] = 1
                else:
                    attr[matrix_of_predictions[j][i]] = attr[matrix_of_predictions[j][i]] + 1
            list_predicted.append(max(attr.items(), key=operator.itemgetter(1))[0])
        return list_predicted


    def fit(self, X, Y=None):
        to_select = math.ceil(len(X) * 0.66)
        for i in range(self.NT):
            df = X.sample(n=to_select, axis='index', random_state=i)
            df2 = Y.sample(n=to_select, axis='index', random_state=i)
            model = cart_random(features=self.F)
            df.reset_index(drop=True, inplace=True)
            df2.reset_index(drop=True, inplace=True)
            model.fit(df, df2)
            self.trees.append(model)
            if len(self.features) > 0:
                for attribute in df.columns:
                    feature_aux = self.count_attributes(model.root, attribute, 0)
                    if attribute in self.features:
                        self.features[attribute] = feature_aux + self.features[attribute]
                    else:
                        self.features[attribute] = feature_aux
            else:
                for attribute in df.columns:
                    feature_aux = self.count_attributes(model.root, attribute, 0)
                    self.features[attribute] = feature_aux
        self.ordered_features = [key for key in sorted(self.features.items(), reverse=True, key=lambda item: item[1])]
        return self

    def count_attributes(self, branch, attribute, occurrence):
        if isinstance(branch['right'], dict) and isinstance(branch['left'], dict):
            if branch['index'] == attribute:
                occurrence = occurrence + 1
            occurrence = self.count_attributes(branch['right'], attribute, occurrence)
            occurrence = self.count_attributes(branch['left'], attribute, occurrence)
        elif isinstance(branch['right'], dict):
            if branch['index'] == attribute:
                occurrence = occurrence + 1
            occurrence = self.count_attributes(branch['right'], attribute, occurrence)
        elif isinstance(branch['left'], dict):
            if branch['index'] == attribute:
                occurrence = occurrence + 1
            occurrence = self.count_attributes(branch['left'], attribute, occurrence)
        else:
            if branch['index'] == attribute:
                occurrence = occurrence + 1
        return occurrence
