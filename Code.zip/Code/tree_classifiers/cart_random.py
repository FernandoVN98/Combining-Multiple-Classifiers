import pandas as pd


class cart_random():
    def __init__(self, max_depth=None, min_size=2, features=1, pre_prunning=False):
        self.max_depth = max_depth
        self.min_size = min_size
        self.depth = 0
        self.features = features
        self.pre_prunning = pre_prunning

    def fit(self, X, Y):
        self.class_values = list(set(y for y in Y))
        self.root = self.get_split(X, Y)
        self.iterative_splitting(self.root, 1)
        return self

    def predict(self, dataset):
        predictions = []
        for index, row in dataset.iterrows():
            if isinstance(row[self.root['index']], str) or isinstance(self.root['value'], str):
                if row[self.root['index']] == self.root['value']:
                    if isinstance(self.root['left'], dict):
                        predictions.append(self.iterative_prediction(self.root['left'], row))
                    else:
                        predictions.append(self.root['left'])
                else:
                    if isinstance(self.root['right'], dict):
                        predictions.append(self.iterative_prediction(self.root['right'], row))
                    else:
                        predictions.append(self.root['right'])
            else:
                if row[self.root['index']] < self.root['value']:
                    if isinstance(self.root['left'], dict):
                        predictions.append(self.iterative_prediction(self.root['left'], row))
                    else:
                        predictions.append(self.root['left'])
                else:
                    if isinstance(self.root['right'], dict):
                        predictions.append(self.iterative_prediction(self.root['right'], row))
                    else:
                        predictions.append(self.root['right'])
        return predictions

    def iterative_prediction(self, node, row):
        if isinstance(row[node['index']], str) or isinstance(node['value'], str):
            if row[node['index']] == node['value']:
                if isinstance(node['left'], dict):
                    return self.iterative_prediction(node['left'], row)
                else:
                    return node['left']
            else:
                if isinstance(node['right'], dict):
                    return self.iterative_prediction(node['right'], row)
                else:
                    return node['right']

        else:
            if row[node['index']] < node['value']:
                if isinstance(node['left'], dict):
                    return self.iterative_prediction(node['left'], row)
                else:
                    return node['left']
            else:
                if isinstance(node['right'], dict):
                    return self.iterative_prediction(node['right'], row)
                else:
                    return node['right']

    def gini_index(self, X, Y, classes):
        gini = 0.0
        n_instances = float(sum([len(group) for group in X]))
        for group, group2 in zip(X, Y):
            size = len(group)
            if size != 0:
                score = 0.0
                for clas in classes:
                    aux = [row for row in group2]
                    p = aux.count(clas) / size
                    score = score + p * p
                gini = gini + (1.0 - score) * (size / n_instances)
        return gini

    def split(self, X, Y, attribute, value):
        if X[attribute].dtype.name == 'category':
            df1 = X[X[attribute] == value]
            yf1 = Y.loc[df1.index, :]
            df2 = X[X[attribute] != value]
            yf2 = Y.loc[df2.index, :]
        else:
            df1 = X[X[attribute] < value]
            yf1 = Y.loc[df1.index]
            df2 = X[X[attribute] >= value]
            yf2 = Y.loc[df2.index]
        return [df1, df2], [yf1, yf2]

    def get_split(self, dataset, Y):
        attributetoreturn, value, score, x_group, y_group = None, 1000000, 1000000, None, None
        df = dataset.sample(n=self.features, axis='columns')
        possible_attributes = df.columns
        for index in dataset.index:
            for attribute in possible_attributes:
                X_aux, Y_aux = self.split(dataset, Y, attribute, dataset[attribute][index])
                gini = self.gini_index(X_aux, Y_aux, self.class_values)
                if gini < score:
                    attributetoreturn, value, score, x_group, y_group = attribute, dataset[attribute][index], gini, X_aux, Y_aux
        return {'index': attributetoreturn, 'value': value, 'groups': [x_group, y_group]}

    def iterative_splitting(self, tree_node, actual_depth):
        tree_node['upper'] = tree_node
        x_group, y_group = tree_node['groups']
        if self.pre_prunning != False:
            if self.gini_index(x_group, y_group, self.class_values) < self.pre_prunning:
                outcomes = [row for row in pd.concat([y_group[1], y_group[0]], axis=0)]
                tree_node['left'] = tree_node['right'] = max(set(outcomes), key=outcomes.count)
                return
        if not len(x_group[0]) != 0:
            outcomes = [row for row in y_group[1]]
            tree_node['left'] = tree_node['right'] = max(set(outcomes), key=outcomes.count)
            return
        elif not len(x_group[1]) != 0:
            outcomes = [row for row in y_group[0]]
            tree_node['left'] = tree_node['right'] = max(set(outcomes), key=outcomes.count)
            return
        if self.max_depth is not None:
            if actual_depth >= self.max_depth:
                tree_node['left'], tree_node['right'] = self.terminal_node(x_group[0], y_group[0]), self.terminal_node(
                    x_group[1], y_group[1])
                return
            if len(y_group[0]) <= self.min_size:
                outcomes = [row for row in y_group[0]]
                tree_node['left'] = max(set(outcomes), key=outcomes.count)
            else:
                tree_node['left'] = self.get_split(x_group[0], y_group[0])
                outcomes = [row for row in y_group[0]]
                tree_node['class'] = max(set(outcomes), key=outcomes.count)
                self.iterative_splitting(tree_node['left'], actual_depth + 1)
            if len(y_group[1]) <= self.min_size:
                outcomes = [row for row in y_group[1]]
                tree_node['right'] = max(set(outcomes), key=outcomes.count)
            else:
                tree_node['right'] = self.get_split(x_group[1], y_group[1])
                outcomes = [row for row in y_group[1]]
                tree_node['class'] = max(set(outcomes), key=outcomes.count)
                self.iterative_splitting(tree_node['right'], actual_depth + 1)
        else:
            if len(y_group[0]) <= self.min_size:
                outcomes = [row for row in y_group[0]]
                tree_node['left'] = max(set(outcomes), key=outcomes.count)
            else:
                tree_node['left'] = self.get_split(x_group[0], y_group[0])
                outcomes = [row for row in y_group[0]]
                tree_node['class'] = max(set(outcomes), key=outcomes.count)
                self.iterative_splitting(tree_node['left'], actual_depth + 1)
            if len(y_group[1]) <= self.min_size:
                outcomes = [row for row in y_group[1]]
                tree_node['right'] = max(set(outcomes), key=outcomes.count)
            else:
                tree_node['right'] = self.get_split(x_group[1], y_group[1])
                outcomes = [row for row in y_group[1]]
                tree_node['class'] = max(set(outcomes), key=outcomes.count)
                self.iterative_splitting(tree_node['right'], actual_depth + 1)
