import operator
import random

from sklearn.tree import DecisionTreeClassifier

from tree_classifiers.cart import cart


class decision_forest():
    def __init__(self, NT=1, F=1, random_F=False, pre_prunning=False):
        self.NT = NT
        self.F = F
        self.random_F=random_F
        self.trees = []
        self.pre_prunning=pre_prunning
        self.features = {}

    def fit(self, X, Y=None):
        for i in range(self.NT):
            if self.random_F!=True:
                df = X.sample(n=self.F, axis='columns', random_state=i)
            else:
                features_random=random.randint(1, self.F)
                df = X.sample(n=features_random, axis='columns', random_state=i)
            model = cart(pre_prunning=self.pre_prunning)
            model.fit(df, Y)
            self.trees.append(model)
            if len(self.features) > 0:
                for attribute in df.columns:
                    feature_aux = self.count_attributes(model.root, attribute, 0)
                    if attribute in self.features:
                        self.features[attribute] = feature_aux + self.features[attribute]
                    else:
                        self.features[attribute] = feature_aux
            else:
                for attribute in df.columns:
                    feature_aux = self.count_attributes(model.root, attribute, 0)
                    self.features[attribute] = feature_aux
        self.ordered_features=[key for key in sorted(self.features.items(),reverse=True, key=lambda item: item[1])]
        return self

    def count_attributes(self, branch, attribute, occurrence):
        if isinstance(branch['right'], dict) and isinstance(branch['left'], dict):
            if branch['index'] == attribute:
                occurrence = occurrence + 1
            occurrence = self.count_attributes(branch['right'], attribute, occurrence)
            occurrence = self.count_attributes(branch['left'], attribute, occurrence)
        elif isinstance(branch['right'], dict):
            if branch['index'] == attribute:
                occurrence = occurrence + 1
            occurrence = self.count_attributes(branch['right'], attribute, occurrence)
        elif isinstance(branch['left'], dict):
            if branch['index'] == attribute:
                occurrence = occurrence + 1
            occurrence = self.count_attributes(branch['left'], attribute, occurrence)
        else:
            if branch['index'] == attribute:
                occurrence = occurrence + 1
        return occurrence
