import os
from argparse import ArgumentParser

from interpreter.interpreter_forest import interpreter_forest
from preprocess.read_dataset import Preprocessing
from tree_classifiers.cart import cart
from tree_classifiers.cart_random import cart_random
from tree_classifiers.decision_forest import decision_forest
from tree_classifiers.random_forest import random_forest
import sys
sys.setrecursionlimit(1000000)

def main():
    parser = ArgumentParser(description="Work 1 - SEL")
    parser.add_argument(
        "-alg",
        "--algorithm",
        type=str,
        choices=["RandomForest", "DecisionForest"],
        help="Select algorithm to use",
        required=True,
    )
    parser.add_argument(
        "-d",
        "--dataset",
        type=str,
        choices=["glass", "winequality-red", "studentInfo"],
        help="Select dataset to use",
        required=True,
    )
    parser.add_argument(
        "-t",
        "--type",
        type=str,
        choices=["arff", "csv"],
        help="Type of dataset",
        required=True,
    )
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        help="Output file",
        required=True,
    )
    parser.add_argument(
        "-NT",
        "--NT",
        type=int,
        default=1,
        help="NT value, number of trees to build.",
        required=False,
    )
    parser.add_argument(
        "-F",
        "--F",
        type=int,
        default=1,
        help="F value, number of random features to use.",
        required=False,
    )
    parser.add_argument(
        "-del",
        "--delimiter",
        type=str,
        default="None",
        help="Delimiter string, used for separating the attributes of a dataset if needed.",
        required=False,
    )

    args = parser.parse_args()

    print(
        "Creating execution with: 'dataset={}'".format(
            args.dataset
        )
    )
    if args.delimiter=="None":
        preproc = Preprocessing(args.dataset, os.path.dirname(os.path.abspath(__file__)))
        X, Y, X_test, Y_test = preproc.get_dataset(flag=args.type, flag_val="No")
        if args.algorithm == "DecisionForest":
            dt = decision_forest(F=args.F, NT=args.NT)
        else:
            dt = random_forest(F=args.F, NT=args.NT)
        dt.fit(X, Y)
        inter = interpreter_forest(dt.trees)
        print("Ordered Features: " + str(dt.ordered_features))
        print("Train Accuracy: " + str(inter.compute_classification_accuracy(X, Y)))
        print("Accuracy: " +str(inter.compute_classification_accuracy(X_test,Y_test)))
    else:
        preproc = Preprocessing(args.dataset, os.path.dirname(os.path.abspath(__file__)))
        X, Y, X_test, Y_test = preproc.get_dataset(flag=args.type, flag_val="No", flag_del=args.delimiter)
        if args.algorithm == "DecisionForest":
            dt = decision_forest(F=args.F, NT=args.NT)
        else:
            dt = random_forest(F=args.F, NT=args.NT)
        dt.fit(X, Y)
        inter = interpreter_forest(dt.trees)
        print("Ordered Features: " + str(dt.ordered_features))
        print("Train Accuracy: " + str(inter.compute_classification_accuracy(X, Y)))
        print("Accuracy: " + str(inter.compute_classification_accuracy(X_test, Y_test)))


if __name__ == "__main__":
    main()